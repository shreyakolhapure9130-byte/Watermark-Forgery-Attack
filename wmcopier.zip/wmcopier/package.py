"""Swap forged group images into the 200-image base and write submission.zip.
  python package.py --base submission_temp --forged forged --lo 51 --hi 75"""
import argparse, glob, os, shutil, zipfile
ap=argparse.ArgumentParser()
ap.add_argument("--base",required=True); ap.add_argument("--forged",required=True)
ap.add_argument("--lo",type=int); ap.add_argument("--hi",type=int)
a=ap.parse_args()
shutil.rmtree("subtmp",ignore_errors=True); os.makedirs("subtmp")
for p in glob.glob(f"{a.base}/*.png"): shutil.copy(p,f"subtmp/{os.path.basename(p)}")
for n in range(a.lo,a.hi+1): shutil.copy(f"{a.forged}/{n}.png",f"subtmp/{n}.png")
files=sorted(glob.glob("subtmp/*.png"),key=lambda p:int(os.path.basename(p)[:-4]))
assert len(files)==200,f"got {len(files)}"
with zipfile.ZipFile("submission.zip","w",zipfile.ZIP_DEFLATED) as z:
    for p in files: z.write(p,arcname=os.path.basename(p))
print("wrote submission.zip",len(files))
