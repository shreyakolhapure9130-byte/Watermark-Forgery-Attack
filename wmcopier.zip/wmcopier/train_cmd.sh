#!/bin/bash
# Train the no-box diffusion attacker on a group's 25 watermarked sources.
# Prereq: git clone https://github.com/holdrain/WMCopier && cd WMCopier && pip install -r requirements.txt
# One-line fix needed in src/trainer.py: ensure `self.dl = dl` before `self.dl_iter = cycle_dataloader(self.dl)`.
# Copy WM_3 sources to $DATA first:  cp Dataset/watermarked_sources/WM_3/*.png $DATA/
DATA=${1:-/content/wm3_train/imgs}
PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True accelerate launch --num_processes 1 --main_process_port 29501 \
  src/train.py --config configs/config.yaml --seed 2025 \
  --train_batchsize 4 --num_samples 4 --image_size 256 --backbone unet \
  --learning_rate 1e-4 --lr_scheduler no --train_num_steps 1000 \
  --gradient_accumulate_every 4 --ema_decay 0.995 --amp \
  --exp_name wm3 --data_path $DATA \
  --save_and_sample_every 500 --train_num 25 --beta_schedule linear
