"""No-box forge: shallow DDIM inversion + refined denoise, blended with clean image.
Run inside the WMCopier repo. Example:
  python forge.py --group WM_3 --res 256 --alpha 0.35 --ckpt experiments/wm3/model-2.pt --lo 51 --hi 75
"""
import os, sys, glob, argparse, numpy as np
sys.path.insert(0, os.path.abspath("src")); sys.path.insert(0, os.path.abspath("."))
from PIL import Image
from torchvision import transforms
from setting import model_choices, beta_schedule_choices
from trainer import load_pretrained_model
from utils.helpers import parse_yml
from easydict import EasyDict
from diffusers import DDIMScheduler, DDIMPipeline
from inversion import pred_latents, sample

ap=argparse.ArgumentParser()
ap.add_argument("--group"); ap.add_argument("--res",type=int,default=256)
ap.add_argument("--alpha",type=float,default=0.35); ap.add_argument("--ckpt",required=True)
ap.add_argument("--lo",type=int); ap.add_argument("--hi",type=int)
ap.add_argument("--dataset",default="Dataset"); ap.add_argument("--out",default="forged")
a=ap.parse_args()
dev="cuda:0"
Tc=EasyDict(parse_yml("configs/config.yaml"))
if not hasattr(Tc,"beta_schedule"): Tc.beta_schedule="linear"
model=model_choices["unet"](a.res).eval().to(dev)
load_pretrained_model(model, accelerator=None, pretrained_ckp=a.ckpt)
pipe=DDIMPipeline(unet=model, scheduler=DDIMScheduler(num_train_timesteps=1000,
     trained_betas=beta_schedule_choices[Tc.beta_schedule]()))
tf=transforms.Compose([transforms.Resize((a.res,a.res)),transforms.ToTensor(),transforms.Normalize([0.5],[0.5])])
os.makedirs(a.out,exist_ok=True)
for n in range(a.lo,a.hi+1):
    orig=Image.open(f"{a.dataset}/clean_targets/{n}.png").convert("RGB"); W,H=orig.size
    x0=tf(orig).unsqueeze(0).to(dev)
    lat=pred_latents(pipe,x0,num_inference_steps=100,end_step=20,device=dev)
    rec,_=sample(x0,pipe,start_step=80,start_latents=lat,num_inference_steps=100,
                 device=dev,refine=True,L=100,eta=0.0001,beta=40)
    rec=x0+a.alpha*(rec-x0)
    out=(rec*0.5+0.5).clamp(0,1).detach().cpu().squeeze().permute(1,2,0).numpy()
    Image.fromarray((out*255).astype("uint8")).resize((W,H)).save(f"{a.out}/{n}.png")
    print("forged",n)
