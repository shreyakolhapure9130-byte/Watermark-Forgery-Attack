"""
try_vine.py -- is WM_8 (or WM_3) the VINE watermark?  Run on Kaggle (GPU+Internet).
Place this in the VINE repo root (so `vine/src` imports resolve) and set DATASET_DIR.
No submission used. Match = sources decode to ONE consistent 100-bit message,
clearly above the clean-image baseline, on VINE-B-Dec or VINE-R-Dec.
"""
import sys, os, glob, numpy as np, torch
sys.path.append("vine/src")                      # so stega_encoder_decoder imports
from stega_encoder_decoder import CustomConvNeXt
from PIL import Image
from torchvision import transforms

DATASET_DIR = os.environ.get("DATASET_DIR", "/kaggle/input/your-dataset/Dataset")  # <-- EDIT
GROUPS = {"WM_3": range(51,76), "WM_8": range(176,201)}
device = "cuda" if torch.cuda.is_available() else "cpu"
t256 = transforms.Compose([transforms.Resize(256, interpolation=transforms.InterpolationMode.BICUBIC),
                           transforms.ToTensor()])

@torch.no_grad()
def decode_bits(decoder, path):
    im = t256(Image.open(path).convert("RGB")).unsqueeze(0).to(device)
    pred = decoder(im)                            # (1,100) in [0,1]
    return np.round(pred[0].cpu().numpy()).astype(int)

def consistency(decoder, paths):
    A = np.stack([decode_bits(decoder, p) for p in paths])
    maj = (A.mean(0) > 0.5)
    return float((A == maj).mean()), maj.astype(int)

for model in ["Shilin-LU/VINE-B-Dec", "Shilin-LU/VINE-R-Dec"]:
    dec = CustomConvNeXt.from_pretrained(model).to(device).eval()
    clean = [f"{DATASET_DIR}/clean_targets/{n}.png" for n in range(1,16)]
    cbase,_ = consistency(dec, clean)
    print(f"\n===== {model}  (clean baseline consistency={cbase:.3f}) =====")
    for g,rng in GROUPS.items():
        src = sorted(glob.glob(f"{DATASET_DIR}/watermarked_sources/{g}/*.png"))
        c,msg = consistency(dec, src)
        flag = "  <== MATCH" if (c>0.85 and c-cbase>0.15) else ""
        print(f"  {g}: consistency={c:.3f}  margin={c-cbase:+.3f}{flag}")
        if flag:
            # show recovered message as 12-char text (VINE packs 12 chars -> 96 bits + 4 pad)
            bits = "".join(str(b) for b in msg[:96])
            chars = "".join(chr(int(bits[i:i+8],2)) for i in range(0,96,8))
            print(f"       recovered secret text: {chars!r}")
