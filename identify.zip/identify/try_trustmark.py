"""
try_trustmark.py -- test whether the unsolved groups are Adobe TrustMark.
  pip install trustmark
Decodes all 25 sources per group; a real match = 'present' fires on nearly all
sources with an IDENTICAL payload, and does NOT fire on clean control images.
No submission used. If a group matches, the recovered secret is printed.
"""
from pathlib import Path
from PIL import Image

DATASET_DIR=Path("Dataset")
GROUPS={"WM_2":(26,50),"WM_3":(51,75),"WM_7":(151,175),"WM_8":(176,200)}
MODEL_TYPES=["Q","P","B"]        # try each TrustMark variant

from trustmark import TrustMark

def parse(res):
    # decode() returns a tuple; pull the bool + the string robustly across versions
    present = next((x for x in res if isinstance(x,bool)), None)
    secret  = next((x for x in res if isinstance(x,str)),  None)
    return present, secret

def decode_group(tm, paths):
    out=[]
    for p in paths:
        try: out.append(parse(tm.decode(Image.open(p).convert("RGB"))))
        except Exception as e: out.append((None,str(e)[:40]))
    return out

for mt in MODEL_TYPES:
    print(f"\n########## TrustMark model_type={mt} ##########")
    try:
        tm=TrustMark(verbose=False, model_type=mt)
    except Exception as e:
        print(f"  could not init ({e}); skipping"); continue
    # clean control
    clean_paths=[DATASET_DIR/"clean_targets"/f"{n}.png" for n in range(1,16)]
    cl=decode_group(tm, clean_paths)
    clean_present=sum(1 for pr,_ in cl if pr)
    print(f"  clean control: watermark 'present' on {clean_present}/15 clean images")
    for g,(a,b) in GROUPS.items():
        paths=sorted((DATASET_DIR/"watermarked_sources"/g).glob("*.png"))
        res=decode_group(tm, paths)
        present=[s for pr,s in res if pr]
        n_present=len(present)
        if n_present>=2:
            # payload consistency
            from collections import Counter
            top,cnt=Counter(present).most_common(1)[0]
            print(f"  {g}: present {n_present}/25 | top payload {cnt}/{n_present} identical"
                  + (f"  <== MATCH secret='{top}'" if (n_present>=20 and cnt>=n_present*0.8 and clean_present<=2) else ""))
        else:
            print(f"  {g}: present {n_present}/25 (no signal)")
