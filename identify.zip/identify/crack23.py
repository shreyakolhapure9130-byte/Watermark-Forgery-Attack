"""
crack23.py -- hunt the true (method,length) for WM_2 & WM_3 the same way WM_1 was
cracked: for each candidate, embed the voted message into clean hosts, decode the
synthetic marks at every length, and keep only candidates whose synthetic
consistency-vs-length fingerprint MATCHES the genuine sources'. No submission used.
  pip install invisible-watermark opencv-python numpy
Prints a ranked table; a real hit has fp_dist small AND margin clearly >0.
"""
import numpy as np, cv2
from pathlib import Path
from imwatermark import WatermarkEncoder, WatermarkDecoder

DATASET_DIR=Path("Dataset")
GROUPS={"WM_2":(26,50),"WM_3":(51,75)}
METHODS=["dwtDct","dwtDctSvd"]
LENS=[8,12,16,20,24,28,32,40,48,56,64,80,96,128,192,256]   # denser grid than before

def bgr(p): return cv2.imread(str(p),cv2.IMREAD_COLOR)
def dec_all(imgs,m,L):
    d=WatermarkDecoder("bits",L); o=[]
    for im in imgs:
        try: b=np.asarray(d.decode(im,m),dtype=int)
        except Exception: return None
        if b.size!=L: return None
        o.append(b)
    return np.stack(o)
def consist(A): maj=(A.mean(0)>0.5); return float((A==maj).mean()),maj.astype(int)
def embed(host,m,msg):
    e=WatermarkEncoder(); e.set_watermark("bits",list(int(x) for x in msg)); return e.encode(host,m)

clean={}
for n in range(1,201):
    im=bgr(DATASET_DIR/"clean_targets"/f"{n}.png"); clean.setdefault(im.shape[:2],[]).append(im)

for g,(a,b) in GROUPS.items():
    srcs=[bgr(p) for p in sorted((DATASET_DIR/"watermarked_sources"/g).glob("*.png"))]
    sz=srcs[0].shape[:2]; hosts=clean.get(sz,[])[:10]
    print(f"\n===== {g} ({sz[0]}x{sz[1]}) =====")
    rows=[]
    for m in METHODS:
        real={L:(consist(dec_all(srcs,m,L))[0] if dec_all(srcs,m,L) is not None else np.nan) for L in LENS}
        base={L:(consist(dec_all(hosts,m,L))[0] if dec_all(hosts,m,L) is not None else np.nan) for L in LENS}
        for L in LENS:
            A=dec_all(srcs,m,L)
            if A is None or np.isnan(real[L]): continue
            margin=real[L]-base[L]
            if margin<0.05: continue                      # skip clear non-signals
            _,msg=consist(A)
            synth=[embed(h.copy(),m,msg) for h in hosts]
            scurve={L2:(consist(dec_all(synth,m,L2))[0] if dec_all(synth,m,L2) is not None else np.nan) for L2 in LENS}
            ls=[L2 for L2 in LENS if not np.isnan(real[L2]) and not np.isnan(scurve[L2])]
            fp=np.mean([abs(real[L2]-scurve[L2]) for L2 in ls])
            rows.append((fp,-margin,m,L,margin))
    rows.sort()
    print(f"  {'method':10s} {'L':>4s} {'margin':>7s} {'fp_dist':>8s}")
    for fp,_,m,L,margin in rows[:8]:
        flag="  <== candidate" if (fp<0.05 and margin>0.08) else ""
        print(f"  {m:10s} {L:>4d} {margin:>7.3f} {fp:>8.3f}{flag}")
    if not rows: print("  no signal above margin 0.05 at any length/method")
