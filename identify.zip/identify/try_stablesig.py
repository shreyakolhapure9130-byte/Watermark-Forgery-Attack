"""
try_stablesig.py -- is WM_8 (or WM_3) Stable Signature?  Run on Kaggle (GPU+Internet).
First download the public 48-bit extractors:
    !mkdir -p models
    !wget -q https://dl.fbaipublicfiles.com/ssl_watermarking/dec_48b_whit.torchscript.pt -P models/
    !wget -q https://dl.fbaipublicfiles.com/ssl_watermarking/other_dec_48b_whit.torchscript.pt -P models/
Match = sources decode to ONE consistent 48-bit message, clearly above the clean
baseline. No submission used.
"""
import os, glob, numpy as np, torch
from PIL import Image
import torchvision.transforms as transforms

DATASET_DIR = os.environ.get("DATASET_DIR", "/kaggle/working/Dataset")  # <-- EDIT
GROUPS = {"WM_3": (51,76), "WM_8": (176,201)}
device = "cuda" if torch.cuda.is_available() else "cpu"
tf = transforms.Compose([transforms.ToTensor(),
     transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])])  # official SS preprocessing

def decode(extractor, path):
    x = tf(Image.open(path).convert("RGB")).unsqueeze(0).to(device)
    with torch.no_grad():
        m = extractor(x)                       # (1,48) logits
    return (m > 0).squeeze().cpu().numpy().astype(int)

def consistency(extractor, paths):
    A = np.stack([decode(extractor, p) for p in paths])
    maj = (A.mean(0) > 0.5)
    return float((A == maj).mean()), maj.astype(int)

for ckpt in ["models/dec_48b_whit.torchscript.pt", "models/other_dec_48b_whit.torchscript.pt"]:
    if not os.path.exists(ckpt):
        print(f"[skip] {ckpt} not found"); continue
    ext = torch.jit.load(ckpt).to(device).eval()
    clean = [f"{DATASET_DIR}/clean_targets/{n}.png" for n in range(1,16)]
    cb,_ = consistency(ext, clean)
    print(f"\n===== {ckpt}  (clean baseline={cb:.3f}) =====")
    for g,(a,b) in GROUPS.items():
        src = sorted(glob.glob(f"{DATASET_DIR}/watermarked_sources/{g}/*.png"))
        c,msg = consistency(ext, src)
        flag = "  <== MATCH (Stable Signature!)" if (c>0.85 and c-cb>0.15) else ""
        print(f"  {g}: consistency={c:.3f}  margin={c-cb:+.3f}{flag}")
        if flag:
            print(f"       48-bit signature: {''.join(map(str,msg))}")
