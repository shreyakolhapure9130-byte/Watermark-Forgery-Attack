"""
resolve2.py -- crack (method, TRUE length) per group by LENGTH-SIGNATURE matching,
then build submission.zip.  pip install invisible-watermark opencv-python numpy scipy

Why signature matching: a dwtDct mark of true length p reads 'consistent' not only
at p but at a characteristic SET of lengths (its divisor/aliasing pattern). Absolute
consistency is polluted by unknown embedding strength; the *pattern of which lengths
light up* is not. So we embed a mark at each candidate length p, record which lengths
it lights up, and pick the p whose synthetic signature matches the real sources'.
"""
import numpy as np, cv2, zipfile
from pathlib import Path
from imwatermark import WatermarkEncoder, WatermarkDecoder
from scipy.ndimage import gaussian_filter, median_filter

DATASET_DIR=Path("Dataset"); OUT=Path("submission_temp"); OUT.mkdir(exist_ok=True)
CATS=[("WM_1",1,25),("WM_2",26,50),("WM_3",51,75),("WM_4",76,100),
      ("WM_5",101,125),("WM_6",126,150),("WM_7",151,175),("WM_8",176,200)]
METHODS=["dwtDct","dwtDctSvd"]; LENS=[16,24,32,48,64,96,128,256]
MARGIN_ON=0.08          # a length "lights up" if src-consistency exceeds clean by this
ADD_FALLBACK={"WM_4":("ghp",0.5,1.6),"WM_5":("medhp",3,1.4),"WM_6":("medhp",5,1.3)}

def bgr(p): return cv2.imread(str(p),cv2.IMREAD_COLOR)
def dec_all(imgs,m,L):
    d=WatermarkDecoder("bits",L); o=[]
    for im in imgs:
        try: b=np.asarray(d.decode(im,m),dtype=int)
        except Exception: return None
        if b.size!=L: return None
        o.append(b)
    return np.stack(o)
def consist(A): maj=(A.mean(0)>0.5); return float((A==maj).mean()),maj.astype(int)
def embed(host,m,msg):
    e=WatermarkEncoder(); e.set_watermark("bits",list(int(x) for x in msg)); return e.encode(host,m)

clean={}
for n in range(1,201):
    im=bgr(DATASET_DIR/"clean_targets"/f"{n}.png"); clean.setdefault(im.shape[:2],[]).append(im)

def signature(imgs,m,base):   # boolean vector: which lengths light up above clean
    sig={}
    for L in LENS:
        A=dec_all(imgs,m,L); sig[L]=(consist(A)[0]-base[L]>MARGIN_ON) if A is not None else False
    return sig

decisions={}
for g,a,b in CATS:
    srcs=[bgr(p) for p in sorted((DATASET_DIR/"watermarked_sources"/g).glob("*.png"))]
    sz=srcs[0].shape[:2]; hosts=clean.get(sz,[])[:10]
    best=None
    for m in METHODS:
        base={L:(consist(dec_all(hosts,m,L))[0] if dec_all(hosts,m,L) is not None else 1.0) for L in LENS}
        real_sig=signature(srcs,m,base)
        if not any(real_sig.values()): continue
        for p in LENS:
            A=dec_all(srcs,m,p)
            if A is None or not real_sig[p]: continue      # candidate must itself light up
            _,msg=consist(A)
            synth=[embed(h.copy(),m,msg) for h in hosts]
            syn_sig=signature(synth,m,base)
            ham=sum(real_sig[L]!=syn_sig[L] for L in LENS)  # signature mismatch (0=perfect)
            margin=consist(A)[0]-base[p]
            if best is None or (ham,-margin)<(best["ham"],-best["margin"]):
                best=dict(m=m,p=p,msg=msg,ham=ham,margin=margin)
    if best and best["ham"]<=1 and best["margin"]>0.08:
        decisions[g]=("native",best)
        print(f"{g}: NATIVE {best['m']} L={best['p']}  sig_mismatch={best['ham']}  margin={best['margin']:.3f}  -> re-embed")
    elif g in ADD_FALLBACK:
        decisions[g]=("additive",ADD_FALLBACK[g]); print(f"{g}: additive copy")
    else:
        info=f"best={best['m']} L={best['p']} ham={best['ham']} margin={best['margin']:.3f}" if best else "no signal"
        decisions[g]=("passthrough",None); print(f"{g}: passthrough ({info})")

# build
def rgb(p): return np.array(cv2.cvtColor(bgr(p),cv2.COLOR_BGR2RGB),dtype=np.float32)
def additive(g,a,b,cfg):
    k,s,sc=cfg; srcs=[rgb(p) for p in sorted((DATASET_DIR/"watermarked_sources"/g).glob("*.png"))]
    res=[im-(gaussian_filter(im,(s,s,0)) if k=="ghp" else median_filter(im,size=(int(s),int(s),1))) for im in srcs]
    d=np.median(res,0); d-=d.mean(); v=d.ravel(); nv=np.linalg.norm(v)+1e-9
    proj=lambda im:(im.ravel()-im.mean())@v/nv; tp=np.mean([proj(im) for im in srcs])*sc
    for n in range(a,b+1):
        t=rgb(DATASET_DIR/"clean_targets"/f"{n}.png"); gg=(tp-proj(t))/nv
        cv2.imwrite(str(OUT/f"{n}.png"),cv2.cvtColor(np.clip(t+gg*d,0,255).astype(np.uint8),cv2.COLOR_RGB2BGR))

for g,a,b in CATS:
    kind,info=decisions[g]
    if kind=="native":
        for n in range(a,b+1):
            cv2.imwrite(str(OUT/f"{n}.png"),embed(bgr(DATASET_DIR/"clean_targets"/f"{n}.png"),info["m"],info["msg"]))
    elif kind=="additive": additive(g,a,b,info)
    else:
        for n in range(a,b+1): cv2.imwrite(str(OUT/f"{n}.png"),bgr(DATASET_DIR/"clean_targets"/f"{n}.png"))

with zipfile.ZipFile("submission.zip","w",zipfile.ZIP_DEFLATED) as z:
    for im in OUT.glob("*.png"): z.write(im,arcname=im.name)
print("\nSaved submission.zip")
