"""
try_wam.py -- is WM_3 (or WM_8) Meta's Watermark Anything (WAM)?

SETUP (run these first):
    git clone https://github.com/facebookresearch/watermark-anything
    cd watermark-anything
    pip install -e .
    mkdir -p checkpoints
    wget https://dl.fbaipublicfiles.com/watermark_anything/wam_mit.pth -P checkpoints/
    # then copy this file into the repo root and run it FROM there:
    python try_wam.py

Set DATASET_DIR below to your assignment's Dataset folder (absolute path).
A match = WAM 'detects' a watermark on nearly all 25 sources (high mask coverage)
with a CONSISTENT 32-bit message, and NOT on clean control images. No submission used.
"""
import os, numpy as np, torch
from pathlib import Path
from PIL import Image

DATASET_DIR = Path(os.environ.get("DATASET_DIR", "../tml_assignment_4/Dataset"))  # <-- EDIT if needed
GROUPS = {"WM_3": (51, 75), "WM_8": (176, 200)}

from notebooks.inference_utils import load_model_from_checkpoint, default_transform
device = "cuda" if torch.cuda.is_available() else "cpu"
wam = load_model_from_checkpoint("checkpoints/params.json", "checkpoints/wam_mit.pth").to(device).eval()

@torch.no_grad()
def detect(path):
    x = default_transform(Image.open(path).convert("RGB")).unsqueeze(0).to(device)
    preds = wam.detect(x)["preds"]                 # (1, 1+nbits, H, W)
    mask = (torch.sigmoid(preds[:, 0:1]) > 0.5).float()
    coverage = mask.mean().item()
    bit_logits = preds[:, 1:]                      # (1, nbits, H, W)
    if mask.sum() < 10:
        return None, coverage
    m = (bit_logits * mask).sum(dim=(2, 3)) / (mask.sum(dim=(2, 3)) + 1e-8)  # (1, nbits)
    bits = (torch.sigmoid(m) > 0.5).int().cpu().numpy().ravel()
    return bits, coverage

def summarize(paths, label):
    msgs, covs = [], []
    for p in paths:
        b, c = detect(p); covs.append(c)
        if b is not None: msgs.append(b)
    if len(msgs) < 2:
        print(f"  {label}: detected on {len(msgs)}/{len(paths)} (avg coverage {np.mean(covs):.2f}) - no signal")
        return
    A = np.stack(msgs); maj = (A.mean(0) > 0.5)
    consistency = float((A == maj).mean())
    print(f"  {label}: detected {len(msgs)}/{len(paths)} | coverage {np.mean(covs):.2f} | msg_consistency {consistency:.3f}")

# clean control
clean_paths = [DATASET_DIR/"clean_targets"/f"{n}.png" for n in range(1, 16)]
print("CLEAN CONTROL:"); summarize(clean_paths, "clean")
for g,(a,b) in GROUPS.items():
    print(f"{g}:"); summarize(sorted((DATASET_DIR/"watermarked_sources"/g).glob("*.png")), g)
