"""
try_rivagan.py -- cheap test: are WM_2/3/8 RivaGAN? (already in invisible-watermark)
RivaGAN is a fixed 32-bit learned watermark. Match = sources decode to one
consistent 32-bit message, clearly above the clean-image baseline.
No submission used.
"""
import numpy as np, cv2
from pathlib import Path
from imwatermark import WatermarkDecoder

DATASET_DIR=Path("Dataset")
GROUPS={"WM_2":(26,50),"WM_3":(51,75),"WM_8":(176,200)}
WatermarkDecoder.loadModel()   # downloads RivaGAN onnx once

def bgr(p): return cv2.imread(str(p),cv2.IMREAD_COLOR)
def dec(im):
    try: return np.asarray(WatermarkDecoder("bits",32).decode(im,"rivaGan"),dtype=int)
    except Exception as e: return None

def consist(imgs):
    A=[dec(im) for im in imgs]; A=[a for a in A if a is not None and a.size==32]
    if len(A)<2: return None,None,0
    A=np.stack(A); maj=(A.mean(0)>0.5); return float((A==maj).mean()), maj.astype(int), len(A)

# clean baseline (256 and 512)
clean={}
for n in range(1,201):
    im=bgr(DATASET_DIR/"clean_targets"/f"{n}.png"); clean.setdefault(im.shape[:2],[]).append(im)
base={sz: consist(v[:20])[0] for sz,v in clean.items()}
print("clean baselines by size:", {f"{k[0]}":round(v,3) for k,v in base.items() if v})

for g,(a,b) in GROUPS.items():
    srcs=[bgr(p) for p in sorted((DATASET_DIR/"watermarked_sources"/g).glob("*.png"))]
    sz=srcs[0].shape[:2]
    c,msg,n=consist(srcs)
    if c is None: print(f"{g}: rivaGan could not decode (size {sz})"); continue
    bl=base.get(sz,np.nan)
    flag="  <== MATCH" if (c>0.85 and c-bl>0.15) else ""
    print(f"{g} ({sz[0]}x{sz[1]}): src_consistency={c:.3f}  clean={bl:.3f}  margin={c-bl:.3f}  (n={n}){flag}")
